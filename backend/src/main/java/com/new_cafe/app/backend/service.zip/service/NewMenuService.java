package com.new_cafe.app.backend.service;

import java.util.List;

import com.new_cafe.app.backend.entity.Menu;

public class NewMenuService implements MenuService {

    @Override
    public List<Menu> getAll() {
        return null;
    }

}
