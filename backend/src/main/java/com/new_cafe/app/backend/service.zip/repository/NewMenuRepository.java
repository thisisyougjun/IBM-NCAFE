package com.new_cafe.app.backend.repository;

import java.util.List;

import com.new_cafe.app.backend.entity.Menu;

public class NewMenuRepository implements MenuRepository {
    @Override
    public List<Menu> findAll() {
        return null;
    }
}
